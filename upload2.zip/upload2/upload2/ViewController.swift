//
//  ViewController.swift
//  upload2
//
//  Created by SoftSages on 17/10/22.
//

import UIKit
import MobileCoreServices
import UniformTypeIdentifiers

class ViewController: UIViewController, UIDocumentPickerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func uploadButtonTapped(_ sender: UIButton) {
        let importMenu = UIDocumentPickerViewController(documentTypes: [String(kUTTypePDF)], in: .import)
        importMenu.delegate = self
        importMenu.modalPresentationStyle = .formSheet
        self.present(importMenu, animated: true, completion: nil)
        // session.uploadTask(with: request, from: data)
        
    }
    
    
    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let myURL = urls.first else {
            
           
            return
            
        }
        print("\(myURL)")
        let fileName = myURL.lastPathComponent
        print(fileName)
        
        //api should be called here as it has to be call on click after selecting the document.
        //api needs a authToken and it will return file path saved on server
        //swagger response for the api on success is
        //here is the response according to swagger
    //    {
    //      "content": "string",
    //      "contextId": "string",
    //      "expiryDate": "2022-10-17T07:03:06.170Z",
    //      "id": "string",
    //      "issueDate": "2022-10-17T07:03:06.170Z",
    //      "metadata": [
    //        {
    //          "dataType": "string",
    //          "entityContext": "string",
    //          "entityType": "string",
    //          "mandatory": true,
    //          "name": "string",
    //          "value": "string",
    //          "webComponentSource": "string",
    //          "webComponentType": "string"
    //        }
    //      ],
    //      "ownerEmail": "string",
    //      "ownerId": "string",
    //      "ownerName": "string",
    //      "ownerType": "string",
    //      "path": "string",
    //      "status": "string",
    //      "tags": [
    //        "string"
    //      ],
    //      "title": "string",
    //      "type": "string"
    //    }
    //it returns server file path on testing it in postman
        //url is  var url =   URL(string: "https://api-uat.softsages.com/hr/document/upload/ownerId/e2cbe0fe31a2ff48ba7890ac23e23b8e")
        //auth token is aupplied along with api in header
        //auth token is eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJTU19BVURJRU5DRSIsInNzOmEiOiJTb2Z0U2FnZXMiLCJuYmYiOjE2NjYwMTcxNjYsImN1c3RvbTpOQU1FIjoiRGFyc2hpdGEgU0EiLCJpc3MiOiJTT0ZUU0FHRVMiLCJzczppcCI6dHJ1ZSwiZXhwIjoxNjY2MDMxNTY2LCJjdXN0b206Uk9MRSI6IlN1cGVyIEFkbWluIiwiaWF0IjoxNjY2MDE3MTY2LCJqdGkiOiIyOTMxNmFjYS1kOTM1LTRjOWQtOTYxZC0xZGEzZWFjOTI5ZTUiLCJzczplIjoiZGFyc2hpdGExNkBzb2Z0c2FnZXMuY29tIiwic3M6dCI6ZmFsc2V9._nXttDDCFrUHH9CVQSdpdafEGwa0ntPZxx4lKr1rSbY
        
        //i was using below approach and it was not working
        
        //func Doc(url: String, docData: Data?, parameters: [String : Any], onCompletion: ((JSON?) -> Void)? = nil, onError: ((Error?) -> Void)? = nil, fileName: String, token : String!){
        //    DispatchQueue.main.asyncAfter(deadline: .now() + 0.33){
        //
        //        self.present(self.VC_loader, animated: false)
        //    }
        //     let headers: HTTPHeaders = [
        //         "Content-type": "multipart/form-data",
        //         "Token": "Bearer " + token
        //     ]
        //
        //     print("Headers => \(headers)")
        //
        //     print("Server Url => \(url)")
        //

        //
        //     Alamofire.upload(multipartFormData: { (multipartFormData) in
        //         if let data = docData{
        //             multipartFormData.append(data, withName: "club_file", fileName: fileName, mimeType: "application/pdf")
        //         }
        //
        //         for (key, value) in parameters {
        //             multipartFormData.append("\(value)".data(using: String.Encoding.utf8)!, withName: key as String)
        //          print("PARAMS => \(multipartFormData)")
        //         }
        //
        //     }, to: url, method: .post, headers: headers) { (result) in
        //         switch result{
        //         case .success(let upload, _, _):
        //             upload.responseJSON { response in
        //
        //                DispatchQueue.main.asyncAfter(deadline: .now() + 0.33){
        //                    self.VC_loader.dismiss(animated: false, completion: nil)
        //                }
        //
        //                 print("Succesfully uploaded")
        //                 if let err = response.error{
        //                     onError?(err)
        //                     return
        //                 }
        //                 print(JSON(response.result.value as Any))
        //                 onCompletion?(JSON(response.result.value as Any))
        //             }
        //         case .failure(let error):
        //             print("Error in upload: \(error.localizedDescription)")
        //             onError?(error)
        //         }
        //     }
        // }
        //
        //}

    }
    private func mimeType(for path: String) -> String {
        let pathExtension = URL(fileURLWithPath: path).pathExtension as NSString
        guard
            let uti = UTTypeCreatePreferredIdentifierForTag(kUTTagClassFilenameExtension, pathExtension, nil)?.takeRetainedValue(),
            let mimetype = UTTypeCopyPreferredTagWithClass(uti, kUTTagClassMIMEType)?.takeRetainedValue()
        else {
            return "application/octet-stream"
        }
        
        return mimetype as String
    }
        
         func documentMenu(_ documentMenu:UIDocumentPickerViewController, didPickDocumentPicker documentPicker: UIDocumentPickerViewController) {
            documentPicker.delegate = self
            present(documentPicker, animated: true, completion: nil)
        }
        
        
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            print("view was cancelled")
            dismiss(animated: true, completion: nil)
        }
    }
    


