//
//  ViewController.swift
//  upload
//
//  Created by SoftSages on 17/10/22.
//

import UIKit
import MobileCoreServices
import UniformTypeIdentifiers
import DropDown
import Alamofire

class addDocumentVC: UIViewController, UIDocumentPickerDelegate {
    
    @IBOutlet weak var documentTypeLabel: UILabel!
 
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var dateView2: UIView!
    @IBOutlet weak var dateView1: UIView!
    @IBOutlet weak var documentTitleLabel: UILabel!
    @IBOutlet weak var toDatefield: UITextField!
    @IBOutlet weak var fromDateField:UITextField!
    
    @IBOutlet weak var docTypeView: UIView!
    @IBOutlet weak var docTitleView: UIView!
    var value = UserDefaults.standard.string(forKey: "authTokeN")
    let dropDown = DropDown()
    
    func selectFiles() {
        let types = UTType.types(tag: "json",
                                 tagClass: UTTagClass.filenameExtension,
                                 conformingTo: nil)
        let documentPickerController = UIDocumentPickerViewController(
                forOpeningContentTypes: types)
        documentPickerController.delegate = self
        self.present(documentPickerController, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "WORKSOFTWALL.png")!)
        documentTypeLabel.layer.cornerRadius = 20
        documentTypeLabel.layer.masksToBounds = true
        documentTitleLabel.layer.cornerRadius = 20
        documentTitleLabel.layer.masksToBounds = true
        dateView1.layer.cornerRadius = 20
        dateView1.layer.masksToBounds = true
        dateView2.layer.cornerRadius = 20
        dateView2.layer.masksToBounds = true
        submitButton.layer.cornerRadius = 20
        submitButton.layer.masksToBounds = true
        dateModule()
       
        
    }
    
    @IBAction func backbuttonTapped(_ sender: UIButton) {
//        let view = storyboard?.instantiateViewController(withIdentifier: "MydocumentsVC") as! MydocumentsVC
//        navigationController?.popViewController(animated: true)
//        print("button")
    }
    
    @IBAction func submitButtonTapped(_ sender: UIButton) {
        
    }
    
    @IBAction func doctTypeButton(_ sender: UIButton) {
        dropDown.anchorView = docTypeView
        let data = ["Financial", "Employment Status", "Work Status", "Personal", "Contractual"]
        dropDown.dataSource = data
        dropDown.show()
        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
          print("Selected item: \(item) at index: \(index)")
            let selecteditem = item
            UserDefaults.standard.set(selecteditem, forKey: "select")
            self.documentTypeLabel.text = item
        }
        
    }
    @IBAction func docTitleButton(_ sender: UIButton) {
        dropDown.anchorView = docTitleView
        let personalData = ["Driver's License", "Permanent Account Number (PAN)", "Photo", "Proof of Identity", "Proof of Residence"]
        let financeData = ["ACH Form","Void Check","W9 Form"]
        let employmentData = ["E-Verify","I-9 Form","Joining Form"]
        let workstatusData = ["CPT EAD","EAD(Any other)","GC EAD","H1B","H4 EAD","L2 EAD","OPT EAD","Work Authorization"]
        let contractualData = ["Exhibit 1","Non-Compete Agreement (NCA)","Non-Solicitation Agreement (NSA)","PO-Client","PO-Vendor",]
       
        let selecteditem = UserDefaults.standard.string(forKey: "select")
        
        if selecteditem == "Financial" {
            
            dropDown.dataSource = financeData
        } else if selecteditem == "Personal" {
            
            dropDown.dataSource = personalData
        }else if selecteditem == "Employment Status" {
            dropDown.dataSource = employmentData
            
        }else if selecteditem == "Work Status" {
            
            dropDown.dataSource = workstatusData
        }else if selecteditem == "Contractual" {
            
            dropDown.dataSource = contractualData
        }
        
        
        dropDown.show()
        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
          print("Selected item: \(item) at index: \(index)")
            let selecteditem = item
            UserDefaults.standard.set(selecteditem, forKey: "select")
            self.documentTitleLabel.text = item
        }
        
    }
    
    @IBAction func uploadDocument(_ sender: UIButton) {
        let importMenu = UIDocumentPickerViewController(documentTypes: [String(kUTTypePDF)], in: .import)
            importMenu.delegate = self
            importMenu.modalPresentationStyle = .formSheet
            self.present(importMenu, animated: true, completion: nil)
       // session.uploadTask(with: request, from: data)

    }
   
    func dateModule(){
        let datepicker = UIDatePicker()
        datepicker.datePickerMode = .date
        datepicker.addTarget(self, action: #selector(dateChange(datepicker:)), for: UIControl.Event.valueChanged)
        datepicker.frame.size = CGSize(width: 0, height: 200)
        datepicker.preferredDatePickerStyle = .inline
        fromDateField.inputView = datepicker
        toDatefield.inputView = datepicker
        
        fromDateField.text = formatdate(date: Date())
        toDatefield.text = formatdate(date: Date())
        //datepicker.minimumDate = Date()
        
        let toolBar = UIToolbar().ToolbarPiker(mySelect: #selector(addDocumentVC.dismissPicker))
        
        fromDateField.inputAccessoryView = toolBar
        toDatefield.inputAccessoryView = toolBar
    }
    
    @objc func dateChange(datepicker: UIDatePicker){
        
        toDatefield.text = formatdate(date: datepicker.date)
        fromDateField.text =  formatdate(date: datepicker.date)
    }
    
    func formatdate(date: Date)-> String{
        
        let formatter = DateFormatter()
        formatter.dateFormat = "MM/dd/yyyy"
        return formatter.string(from: date)
    }
    
    @objc func dismissPicker() {
        
        view.endEditing(true)
        
    }
    // I am calling the api here is because it needs to be called when the file get selected and uploaded to device. but we dont require the user to see whats uploaded
    //according to swagger documentation the api needs only file in multipart form data and returns reponse for path of file in server
    //here is the response according to swagger
//    {
//      "content": "string",
//      "contextId": "string",
//      "expiryDate": "2022-10-17T07:03:06.170Z",
//      "id": "string",
//      "issueDate": "2022-10-17T07:03:06.170Z",
//      "metadata": [
//        {
//          "dataType": "string",
//          "entityContext": "string",
//          "entityType": "string",
//          "mandatory": true,
//          "name": "string",
//          "value": "string",
//          "webComponentSource": "string",
//          "webComponentType": "string"
//        }
//      ],
//      "ownerEmail": "string",
//      "ownerId": "string",
//      "ownerName": "string",
//      "ownerType": "string",
//      "path": "string",
//      "status": "string",
//      "tags": [
//        "string"
//      ],
//      "title": "string",
//      "type": "string"
//    }
    
    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let myURL = urls.first else {
            return
        }
        var url =   URL(string: "https://api-uat.softsages.com/hr/document/upload/ownerId/e2cbe0fe31a2ff48ba7890ac23e23b8e")
        print("import result : \(myURL)")
        let fileName = myURL.lastPathComponent
        print("import result : \(fileName)")
         var token = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJTU19BVURJRU5DRSIsInNzOmEiOiJTb2Z0U2FnZXMiLCJuYmYiOjE2NjU5ODk5NjIsImN1c3RvbTpOQU1FIjoiRGFyc2hpdGEgU0EiLCJpc3MiOiJTT0ZUU0FHRVMiLCJzczppcCI6dHJ1ZSwiZXhwIjoxNjY2MDA0MzYyLCJjdXN0b206Uk9MRSI6IlN1cGVyIEFkbWluIiwiaWF0IjoxNjY1OTg5OTYyLCJqdGkiOiIzZjIwZWNmNi1hODBkLTQ4NWMtYWIxNy00ZjJiNWI0NDk2YmQiLCJzczplIjoiZGFyc2hpdGExNkBzb2Z0c2FnZXMuY29tIiwic3M6dCI6ZmFsc2V9.fhJELOLC08K2CJaNjXWQyHoTF-qPdTJ7FN7_DqFlBCE"
        
        func Doc(url: String, docData: Data?, parameters: [String : Any], onCompletion: ((JSON?) -> Void)? = nil, onError: ((Error?) -> Void)? = nil, fileName: String, token : String!){
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.33)
             let headers: HTTPHeaders = [
                 "Content-type": "multipart/form-data",
                 "Token": "Bearer " + token
             ]

             print("Headers => \(headers)")

             print("Server Url => \(url)")

        //  Alamofire.upload(multipartFormData: <#T##(MultipartFormData) -> Void#>, to: <#T##URLConvertible#>, encodingCompletion: <#T##((SessionManager.MultipartFormDataEncodingResult) -> Void)?##((SessionManager.MultipartFormDataEncodingResult) -> Void)?##(SessionManager.MultipartFormDataEncodingResult) -> Void#>)

             Alamofire.upload(multipartFormData: { (multipartFormData) in
                 if let data = docData{
                     multipartFormData.append(data, withName: "club_file", fileName: fileName, mimeType: "application/pdf")
                 }

                 for (key, value) in parameters {
                     multipartFormData.append("\(value)".data(using: String.Encoding.utf8)!, withName: key as String)
                  print("PARAMS => \(multipartFormData)")
                 }

             }, to: url, method: .post, headers: headers) { (result) in
                 switch result{
                 case .success(let upload, _, _):
                     upload.responseJSON { response in

                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.33){
                            self.VC_loader.dismiss(animated: false, completion: nil)
                        }

                         print("Succesfully uploaded")
                         if let err = response.error{
                             onError?(err)
                             return
                         }
                         print(JSON(response.result.value as Any))
                         onCompletion?(JSON(response.result.value as Any))
                     }
                 case .failure(let error):
                     print("Error in upload: \(error.localizedDescription)")
                     onError?(error)
                 }
             }
         }

        }
 
    }
    private func mimeType(for path: String) -> String {
        let pathExtension = URL(fileURLWithPath: path).pathExtension as NSString
        guard
            let uti = UTTypeCreatePreferredIdentifierForTag(kUTTagClassFilenameExtension, pathExtension, nil)?.takeRetainedValue(),
            let mimetype = UTTypeCopyPreferredTagWithClass(uti, kUTTagClassMIMEType)?.takeRetainedValue()
        else {
            return "application/octet-stream"
        }
        
        return mimetype as String
    }

    public func documentMenu(_ documentMenu:UIDocumentPickerViewController, didPickDocumentPicker documentPicker: UIDocumentPickerViewController) {
        documentPicker.delegate = self
        present(documentPicker, animated: true, completion: nil)
    }


    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        print("view was cancelled")
        dismiss(animated: true, completion: nil)
    }
    
}

extension UIToolbar {
    
    func DatePicker(mySelect : Selector) -> UIToolbar {
        
        let toolBar = UIToolbar()
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.black
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.plain, target: self, action: mySelect)
        let cancel = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.done, target: self, action: mySelect)
        
        
        toolBar.setItems([doneButton, cancel], animated: false)
        
        toolBar.isUserInteractionEnabled = true
        
        return toolBar
    }
    
}


func Doc(url: String, docData: Data?, parameters: [String : Any], onCompletion: ((JSON?) -> Void)? = nil, onError: ((Error?) -> Void)? = nil, fileName: String, token : String!){
    DispatchQueue.main.asyncAfter(deadline: .now() + 0.33){

        self.present(self.VC_loader, animated: false)
    }
     let headers: HTTPHeaders = [
         "Content-type": "multipart/form-data",
         "Token": "Bearer " + token
     ]

     print("Headers => \(headers)")

     print("Server Url => \(url)")

//  Alamofire.upload(multipartFormData: <#T##(MultipartFormData) -> Void#>, to: <#T##URLConvertible#>, encodingCompletion: <#T##((SessionManager.MultipartFormDataEncodingResult) -> Void)?##((SessionManager.MultipartFormDataEncodingResult) -> Void)?##(SessionManager.MultipartFormDataEncodingResult) -> Void#>)

     Alamofire.upload(multipartFormData: { (multipartFormData) in
         if let data = docData{
             multipartFormData.append(data, withName: "club_file", fileName: fileName, mimeType: "application/pdf")
         }

         for (key, value) in parameters {
             multipartFormData.append("\(value)".data(using: String.Encoding.utf8)!, withName: key as String)
          print("PARAMS => \(multipartFormData)")
         }

     }, to: url, method: .post, headers: headers) { (result) in
         switch result{
         case .success(let upload, _, _):
             upload.responseJSON { response in

                DispatchQueue.main.asyncAfter(deadline: .now() + 0.33){
                    self.VC_loader.dismiss(animated: false, completion: nil)
                }

                 print("Succesfully uploaded")
                 if let err = response.error{
                     onError?(err)
                     return
                 }
                 print(JSON(response.result.value as Any))
                 onCompletion?(JSON(response.result.value as Any))
             }
         case .failure(let error):
             print("Error in upload: \(error.localizedDescription)")
             onError?(error)
         }
     }
 }

}

